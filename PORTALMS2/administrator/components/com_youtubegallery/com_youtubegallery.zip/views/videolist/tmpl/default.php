<?php
/**
 * YoutubeGallery Joomla! 3.0 Native Component
 * @version 3.5.9
 * @author DesignCompass corp< <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
 
// load tooltip behavior
JHtml::_('behavior.tooltip');


?>
<form action="<?php echo JRoute::_('index.php?option=com_youtubegallery&view=videolist'); ?>" method="post" name="adminForm" id="adminForm">
<?php
	$s=JRequest::getVar( 'search');
?>
	<h3>Videos of this page: <?php echo count($this->items); ?></h3>
	<?php

		if(count($this->items)==0)
			echo '<p><b>Não foram encontrados vídeos. Tente "Refresh" da galeria, ou adicionar vídeos. </b><br/>Para atualizar vá para a página anterior, verifique o "checkbox" próximo a esta galeria e clique no botão "Atualizar" no barra de ferramentas.</p>';
	?>

<div id="j-main-container" class="span10">
		<div id="filter-bar" class="btn-toolbar">
			<div class="filter-search btn-group pull-left">
				<label for="search" class="element-invisible">Search title.</label>
				<input type="text" name="search" placeholder="Search title." id="search" value="<?php echo $s; ?>" title="Search title." />
			</div>
			<div class="btn-group pull-left hidden-phone">
				<button class="btn tip hasTooltip" type="submit" title="Search"><i class="icon-search"></i></button>
				<button class="btn tip hasTooltip" type="button" onclick="document.id('search').value='';this.form.submit();" title="Clear"><i class="icon-remove"></i></button>
			</div>
			
</div>
		</div>




        <table class="table table-striped">
                <thead><?php echo $this->loadTemplate('head');?></thead>
                <tfoot><?php echo $this->loadTemplate('foot');?></tfoot>
                <tbody><?php echo $this->loadTemplate('body');?></tbody>
        </table>
        <div>
                <input type="hidden" id="task" name="task" value="" />
				
				
<?php 				/* <input type="hidden" name="view" value="videolist" /> */ ?>
				<input type="hidden" name="listid" value="<?php echo JRequest::getInt( 'listid'); ?>" />

                <?php echo JHtml::_('form.token'); ?>
        </div>
		
	<p>
		Se o status do vídeo é "-", isso significa que ele ainda não está marcado.<br/>Vá para o front-end e procure este vídeo em sua galeria, os dados que você verá em miniatura são os dados que estão cadastrados aqui.
	</p>
	
</form>


