<?php
/**
 * YoutubeGallery Joomla! 3.0 Native Component
 * @version 3.5.9
 * @author DesignCompass corp< <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<h4>Advanced</h4>
	<table style="border:none;">
		<tbody>
                                        
										<tr><td><?php echo $this->form->getLabel('themedescription'); ?></td><td>:</td><td><?php echo $this->form->getInput('themedescription'); ?></td></tr>
										

		</tbody>
	</table>

