CREATE TABLE IF NOT EXISTS `#__youtubegallery_settings` (
  `option` varchar(50) NOT NULL,
  `value` varchar(255),

  PRIMARY KEY (`option`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;