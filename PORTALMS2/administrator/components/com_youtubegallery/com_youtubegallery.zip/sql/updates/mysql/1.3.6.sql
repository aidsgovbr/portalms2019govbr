CREATE TABLE IF NOT EXISTS `#__youtubegallery_categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(50) NOT NULL,

  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;